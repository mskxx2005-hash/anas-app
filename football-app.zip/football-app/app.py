import streamlit as st

st.set_page_config(
    page_title="Football Data Analysis",
    page_icon="⚽",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("⚽ Football Data Analysis")
st.markdown("Welcome! Use the sidebar to navigate between sections.")

st.info("Select a page from the sidebar to get started.")

col1, col2, col3 = st.columns(3)
with col1:
    st.metric("Live Scores", "→ Dashboard")
with col2:
    st.metric("Standings", "→ Standings")
with col3:
    st.metric("Top Scorers", "→ Top Scorers")
