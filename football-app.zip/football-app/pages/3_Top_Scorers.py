import streamlit as st
import pandas as pd
import plotly.express as px
from utils.api import get_top_scorers

st.set_page_config(page_title="Top Scorers", page_icon="🥅", layout="wide")

st.title("🥅 Top Scorers")

LEAGUES = {
    "Premier League (England)": (39, 2024),
    "La Liga (Spain)": (140, 2024),
    "Serie A (Italy)": (135, 2024),
    "Bundesliga (Germany)": (78, 2024),
    "Ligue 1 (France)": (61, 2024),
    "Champions League": (2, 2024),
    "Europa League": (3, 2024),
}

league_name = st.selectbox("Select League", list(LEAGUES.keys()))
league_id, season = LEAGUES[league_name]

with st.spinner(f"Loading top scorers for {league_name}..."):
    try:
        scorers = get_top_scorers(league_id, season)
    except Exception as e:
        st.error(f"Error: {e}")
        scorers = []

if not scorers:
    st.info("No data available.")
else:
    rows = []
    for entry in scorers[:20]:
        player = entry["player"]
        stats = entry["statistics"][0] if entry.get("statistics") else {}
        goals = stats.get("goals", {})
        games = stats.get("games", {})
        rows.append({
            "Player": player["name"],
            "Team": stats.get("team", {}).get("name", "—"),
            "Nationality": player.get("nationality", "—"),
            "Age": player.get("age", "—"),
            "Goals": goals.get("total") or 0,
            "Assists": goals.get("assists") or 0,
            "Appearances": games.get("appearences") or 0,
            "Penalties": goals.get("pens", {}).get("scored") if isinstance(goals.get("pens"), dict) else 0,
        })

    df = pd.DataFrame(rows)

    col1, col2 = st.columns([2, 3])

    with col1:
        st.subheader("Rankings Table")
        st.dataframe(df, use_container_width=True, hide_index=True)

    with col2:
        st.subheader("Goals Chart")
        top10 = df.head(10).sort_values("Goals", ascending=True)
        fig = px.bar(
            top10,
            x="Goals",
            y="Player",
            orientation="h",
            color="Goals",
            color_continuous_scale="Reds",
            title=f"Top 10 Scorers — {league_name}",
        )
        fig.update_layout(showlegend=False, coloraxis_showscale=False)
        st.plotly_chart(fig, use_container_width=True)

    st.caption(f"Season {season}/{season+1} · Top {len(df)} players")
