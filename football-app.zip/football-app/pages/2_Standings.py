import streamlit as st
import pandas as pd
from utils.api import get_standings

st.set_page_config(page_title="Standings", page_icon="🏆", layout="wide")

st.title("🏆 League Standings")

LEAGUES = {
    "Premier League (England)": (39, 2024),
    "La Liga (Spain)": (140, 2024),
    "Serie A (Italy)": (135, 2024),
    "Bundesliga (Germany)": (78, 2024),
    "Ligue 1 (France)": (61, 2024),
    "Champions League": (2, 2024),
    "Europa League": (3, 2024),
}

league_name = st.selectbox("Select League", list(LEAGUES.keys()))
league_id, season = LEAGUES[league_name]

with st.spinner(f"Loading standings for {league_name}..."):
    try:
        standings = get_standings(league_id, season)
    except Exception as e:
        st.error(f"Error fetching standings: {e}")
        standings = []

if not standings:
    st.info("No standings data available.")
else:
    rows = []
    for team in standings:
        rows.append({
            "Pos": team["rank"],
            "Team": team["team"]["name"],
            "P": team["all"]["played"],
            "W": team["all"]["win"],
            "D": team["all"]["draw"],
            "L": team["all"]["lose"],
            "GF": team["all"]["goals"]["for"],
            "GA": team["all"]["goals"]["against"],
            "GD": team["goalsDiff"],
            "Pts": team["points"],
            "Form": team.get("form", ""),
        })

    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)
    st.caption(f"Season {season}/{season+1}")
