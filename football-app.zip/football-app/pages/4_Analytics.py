import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from utils.api import get_standings

st.set_page_config(page_title="Analytics", page_icon="📊", layout="wide")

st.title("📊 League Analytics")

LEAGUES = {
    "Premier League (England)": (39, 2024),
    "La Liga (Spain)": (140, 2024),
    "Serie A (Italy)": (135, 2024),
    "Bundesliga (Germany)": (78, 2024),
    "Ligue 1 (France)": (61, 2024),
    "Champions League": (2, 2024),
    "Europa League": (3, 2024),
}

league_name = st.selectbox("Select League", list(LEAGUES.keys()))
league_id, season = LEAGUES[league_name]

with st.spinner(f"Loading analytics for {league_name}..."):
    try:
        standings = get_standings(league_id, season)
    except Exception as e:
        st.error(f"Error fetching data: {e}")
        standings = []

if not standings:
    st.info("No data available for this league.")
    st.stop()

rows = []
for team in standings:
    rows.append({
        "Team": team["team"]["name"],
        "Rank": team["rank"],
        "Goals For": team["all"]["goals"]["for"],
        "Goals Against": team["all"]["goals"]["against"],
        "Wins": team["all"]["win"],
        "Draws": team["all"]["draw"],
        "Losses": team["all"]["lose"],
        "Points": team["points"],
        "GD": team["goalsDiff"],
        "Form": team.get("form", ""),
        "Played": team["all"]["played"],
    })

df = pd.DataFrame(rows)

st.divider()

# ── Chart 1: Goals scored & conceded per team ────────────────────────────────
st.subheader("⚽ Goals Scored vs Goals Conceded")

goals_df = df[["Team", "Goals For", "Goals Against"]].copy()
goals_df = goals_df.sort_values("Goals For", ascending=False)

fig_goals = go.Figure()
fig_goals.add_trace(go.Bar(
    name="Goals Scored",
    x=goals_df["Team"],
    y=goals_df["Goals For"],
    marker_color="#2ecc71",
))
fig_goals.add_trace(go.Bar(
    name="Goals Conceded",
    x=goals_df["Team"],
    y=goals_df["Goals Against"],
    marker_color="#e74c3c",
))
fig_goals.update_layout(
    barmode="group",
    xaxis_tickangle=-45,
    xaxis_title="Team",
    yaxis_title="Goals",
    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    height=500,
    plot_bgcolor="rgba(0,0,0,0)",
    paper_bgcolor="rgba(0,0,0,0)",
)
fig_goals.update_xaxes(showgrid=False)
fig_goals.update_yaxes(gridcolor="rgba(128,128,128,0.2)")
st.plotly_chart(fig_goals, use_container_width=True)

st.divider()

# ── Chart 2: Top 5 team performance trend from form string ───────────────────
st.subheader("📈 Performance Trend — Top 5 Teams")
st.caption("Cumulative points from last matches based on recent form (W=3, D=1, L=0)")

top5 = df.nsmallest(5, "Rank")[["Team", "Form", "Rank"]].copy()

fig_trend = go.Figure()

POINT_MAP = {"W": 3, "D": 1, "L": 0}
COLORS = ["#3498db", "#e67e22", "#9b59b6", "#1abc9c", "#e74c3c"]

for i, row in top5.iterrows():
    form = row["Form"] or ""
    pts = [POINT_MAP.get(r, 0) for r in form]
    if not pts:
        continue
    cumulative = []
    total = 0
    for p in pts:
        total += p
        cumulative.append(total)
    match_nums = list(range(1, len(cumulative) + 1))
    color = COLORS[top5.index.get_loc(i) % len(COLORS)]
    fig_trend.add_trace(go.Scatter(
        x=match_nums,
        y=cumulative,
        mode="lines+markers",
        name=f"{row['Rank']}. {row['Team']}",
        line=dict(width=2.5, color=color),
        marker=dict(size=6, color=color),
    ))

fig_trend.update_layout(
    xaxis_title="Match (recent form window)",
    yaxis_title="Cumulative Points",
    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    height=450,
    plot_bgcolor="rgba(0,0,0,0)",
    paper_bgcolor="rgba(0,0,0,0)",
    hovermode="x unified",
)
fig_trend.update_xaxes(showgrid=False, dtick=1)
fig_trend.update_yaxes(gridcolor="rgba(128,128,128,0.2)")
st.plotly_chart(fig_trend, use_container_width=True)

st.divider()

# ── Chart 3: Win/Draw/Loss breakdown for all teams ───────────────────────────
st.subheader("🏅 Win / Draw / Loss Breakdown")

wdl_df = df[["Team", "Wins", "Draws", "Losses"]].sort_values("Wins", ascending=False)

fig_wdl = go.Figure()
fig_wdl.add_trace(go.Bar(name="Wins",   x=wdl_df["Team"], y=wdl_df["Wins"],   marker_color="#2ecc71"))
fig_wdl.add_trace(go.Bar(name="Draws",  x=wdl_df["Team"], y=wdl_df["Draws"],  marker_color="#f39c12"))
fig_wdl.add_trace(go.Bar(name="Losses", x=wdl_df["Team"], y=wdl_df["Losses"], marker_color="#e74c3c"))
fig_wdl.update_layout(
    barmode="stack",
    xaxis_tickangle=-45,
    xaxis_title="Team",
    yaxis_title="Matches",
    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    height=480,
    plot_bgcolor="rgba(0,0,0,0)",
    paper_bgcolor="rgba(0,0,0,0)",
)
fig_wdl.update_xaxes(showgrid=False)
fig_wdl.update_yaxes(gridcolor="rgba(128,128,128,0.2)")
st.plotly_chart(fig_wdl, use_container_width=True)

st.caption(f"Season {season}/{season + 1} · {league_name} · {len(df)} teams")
