import streamlit as st
import pandas as pd
from datetime import date, datetime
from utils.api import get_fixtures_by_date, get_standings, get_head_to_head

st.set_page_config(page_title="Today's Fixtures", page_icon="📅", layout="wide")

st.title("📅 Today's Fixtures & Smart Predictions")

today = str(date.today())
st.caption(f"Date: {datetime.now().strftime('%A, %d %B %Y')}")

# ── Fetch today's fixtures ────────────────────────────────────────────────────
with st.spinner("Loading today's fixtures..."):
    try:
        fixtures = get_fixtures_by_date(today)
    except Exception as e:
        st.error(f"Error: {e}")
        fixtures = []

if not fixtures:
    st.info("No fixtures scheduled for today.")
    st.stop()

# ── Separate into upcoming / live / finished ──────────────────────────────────
upcoming, live_now, finished = [], [], []
for f in fixtures:
    s = f["fixture"]["status"]["short"]
    if s in ("NS", "TBD"):
        upcoming.append(f)
    elif s in ("FT", "AET", "PEN", "AWD", "WO"):
        finished.append(f)
    else:
        live_now.append(f)

# ── Summary metrics ───────────────────────────────────────────────────────────
m1, m2, m3 = st.columns(3)
m1.metric("⏳ Upcoming", len(upcoming))
m2.metric("🔴 Live Now", len(live_now))
m3.metric("✅ Finished", len(finished))
st.divider()

# ── Group fixtures by league ──────────────────────────────────────────────────
def group_by_league(fix_list):
    grouped = {}
    for f in fix_list:
        key = (f["league"]["name"], f["league"]["country"], f["league"]["id"], f["league"].get("logo", ""))
        grouped.setdefault(key, []).append(f)
    return grouped

def format_kickoff(f):
    d = f["fixture"].get("date", "")
    return d[11:16] + " UTC" if len(d) >= 16 else "TBD"

# ── Standings cache to avoid redundant API calls ──────────────────────────────
@st.cache_data(ttl=600, show_spinner=False)
def cached_standings(league_id, season):
    try:
        return get_standings(league_id, season)
    except Exception:
        return []

def build_form_map(standings):
    return {t["team"]["id"]: {
        "form": t.get("form", ""),
        "rank": t["rank"],
        "pts": t["points"],
        "gf": t["all"]["goals"]["for"],
        "ga": t["all"]["goals"]["against"],
        "played": t["all"]["played"],
        "wins": t["all"]["win"],
    } for t in standings}

POINT_MAP = {"W": 3, "D": 1, "L": 0}

def form_score(form_str: str, last_n: int = 5) -> float:
    pts = [POINT_MAP.get(c, 0) for c in (form_str or "")[-last_n:]]
    return sum(pts) / max(len(pts), 1)

def predict_match(home_id, away_id, home_name, away_name, form_map, h2h_records):
    info = {}

    home_d = form_map.get(home_id)
    away_d = form_map.get(away_id)

    # Base scores
    home_score = 1.1  # home advantage
    away_score = 1.0

    if home_d:
        fs = form_score(home_d["form"])
        gr = (home_d["gf"] / max(home_d["played"], 1))
        home_score += fs * 0.5 + gr * 0.2
        info["home_form"] = home_d["form"][-5:] if home_d["form"] else "N/A"
        info["home_rank"] = home_d["rank"]
        info["home_pts"] = home_d["pts"]
        info["home_gf"] = home_d["gf"]
        info["home_ga"] = home_d["ga"]

    if away_d:
        fs = form_score(away_d["form"])
        gr = (away_d["gf"] / max(away_d["played"], 1))
        away_score += fs * 0.5 + gr * 0.2
        info["away_form"] = away_d["form"][-5:] if away_d["form"] else "N/A"
        info["away_rank"] = away_d["rank"]
        info["away_pts"] = away_d["pts"]
        info["away_gf"] = away_d["gf"]
        info["away_ga"] = away_d["ga"]

    # H2H adjustment
    h2h_home_wins = h2h_draws = h2h_away_wins = 0
    for match in h2h_records:
        mh = match["teams"]["home"]
        ma = match["teams"]["away"]
        mg = match["goals"]
        if mg["home"] is None or mg["away"] is None:
            continue
        if mh["id"] == home_id:
            if mg["home"] > mg["away"]: h2h_home_wins += 1
            elif mg["home"] == mg["away"]: h2h_draws += 1
            else: h2h_away_wins += 1
        else:
            if mg["away"] > mg["home"]: h2h_home_wins += 1
            elif mg["home"] == mg["away"]: h2h_draws += 1
            else: h2h_away_wins += 1

    total_h2h = h2h_home_wins + h2h_draws + h2h_away_wins
    if total_h2h > 0:
        home_score += (h2h_home_wins / total_h2h) * 0.4
        away_score += (h2h_away_wins / total_h2h) * 0.4
        info["h2h"] = f"{home_name} {h2h_home_wins}W – {h2h_draws}D – {h2h_away_wins}W {away_name} (last {total_h2h})"
    else:
        info["h2h"] = "No H2H data"

    # Convert to probabilities
    draw_score = (home_score + away_score) * 0.35
    total = home_score + draw_score + away_score
    hw = round(home_score / total * 100)
    dr = round(draw_score / total * 100)
    aw = 100 - hw - dr

    if hw > dr and hw > aw:
        verdict = f"🏠 **{home_name} Win** favoured"
        conf = "High" if hw > 50 else "Moderate"
    elif aw > dr and aw > hw:
        verdict = f"✈️ **{away_name} Win** favoured"
        conf = "High" if aw > 50 else "Moderate"
    else:
        verdict = "🤝 **Draw** is likely"
        conf = "Low"

    return {"home_pct": hw, "draw_pct": dr, "away_pct": aw, "verdict": verdict, "confidence": conf, "info": info}

def form_badges(form_str):
    badges = {"W": "🟢", "D": "🟡", "L": "🔴"}
    return " ".join(badges.get(c, "⚪") for c in (form_str or "")[-5:]) or "—"

# ─────────────────────────────────────────────────────────────────────────────
# SECTION: Upcoming matches with Smart Predictions
# ─────────────────────────────────────────────────────────────────────────────
st.subheader("⏳ Upcoming Matches")

if not upcoming:
    st.info("No upcoming fixtures for today.")
else:
    grouped = group_by_league(upcoming)
    current_season = 2024

    for (league_name, country, league_id, league_logo), matches in grouped.items():
        with st.expander(f"🏆 {league_name} — {country} ({len(matches)} matches)", expanded=True):

            standings = cached_standings(league_id, current_season)
            form_map = build_form_map(standings) if standings else {}

            for f in matches:
                home_team = f["teams"]["home"]
                away_team = f["teams"]["away"]
                home_id   = home_team["id"]
                away_id   = away_team["id"]
                ko        = format_kickoff(f)

                st.markdown(f"**{home_team['name']} vs {away_team['name']}** — 🕐 {ko}")

                with st.spinner("Analysing…"):
                    try:
                        h2h = get_head_to_head(home_id, away_id, last=10)
                    except Exception:
                        h2h = []

                pred = predict_match(home_id, away_id, home_team["name"], away_team["name"], form_map, h2h)
                info = pred["info"]

                col_a, col_b, col_c = st.columns(3)
                col_a.metric(f"🏠 {home_team['name']} Win", f"{pred['home_pct']}%")
                col_b.metric("🤝 Draw", f"{pred['draw_pct']}%")
                col_c.metric(f"✈️ {away_team['name']} Win", f"{pred['away_pct']}%")

                st.markdown(f"**Prediction:** {pred['verdict']}  \n**Confidence:** {pred['confidence']}")

                detail_cols = st.columns(2)
                with detail_cols[0]:
                    if "home_form" in info:
                        st.caption(f"**{home_team['name']}** — Rank #{info.get('home_rank','?')} · {info.get('home_pts','?')} pts · Form: {form_badges(info['home_form'])}")
                    if "away_form" in info:
                        st.caption(f"**{away_team['name']}** — Rank #{info.get('away_rank','?')} · {info.get('away_pts','?')} pts · Form: {form_badges(info['away_form'])}")
                with detail_cols[1]:
                    st.caption(f"⚔️ H2H: {info.get('h2h','—')}")

                st.markdown("---")

# ─────────────────────────────────────────────────────────────────────────────
# SECTION: Live now (summary only — see Live Center for full stats)
# ─────────────────────────────────────────────────────────────────────────────
if live_now:
    st.divider()
    st.subheader("🔴 Matches Live Right Now")
    st.info("Head to **Live Center** in the sidebar for real-time stats and AI insights.")
    rows = []
    for f in live_now:
        g = f["goals"]
        rows.append({
            "League": f["league"]["name"],
            "Home": f["teams"]["home"]["name"],
            "Score": f"{g['home'] or 0} – {g['away'] or 0}",
            "Away": f["teams"]["away"]["name"],
            "Min": f"{f['fixture']['status']['elapsed']}'" if f["fixture"]["status"]["elapsed"] else "—",
        })
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

# ─────────────────────────────────────────────────────────────────────────────
# SECTION: Finished matches
# ─────────────────────────────────────────────────────────────────────────────
if finished:
    st.divider()
    st.subheader("✅ Finished Today")
    rows = []
    for f in finished:
        g = f["goals"]
        rows.append({
            "League": f["league"]["name"],
            "Home": f["teams"]["home"]["name"],
            "Score": f"{g['home'] or 0} – {g['away'] or 0}",
            "Away": f["teams"]["away"]["name"],
            "Result": ("Home Win" if (g["home"] or 0) > (g["away"] or 0) else
                       "Away Win" if (g["away"] or 0) > (g["home"] or 0) else "Draw"),
        })
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

st.caption(f"⚠️ Predictions are based on form & H2H data — for entertainment only.")
