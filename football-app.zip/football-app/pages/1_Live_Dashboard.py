import streamlit as st
import pandas as pd
from datetime import date
from utils.api import get_live_fixtures, get_fixtures_by_date

st.set_page_config(page_title="Live Dashboard", page_icon="📺", layout="wide")

st.title("📺 Live Match Dashboard")

tab1, tab2 = st.tabs(["🔴 Live Now", "📅 By Date"])

with tab1:
    st.subheader("Matches Currently Live")
    if st.button("🔄 Refresh Live Scores", key="refresh_live"):
        st.rerun()

    with st.spinner("Fetching live matches..."):
        try:
            fixtures = get_live_fixtures()
        except Exception as e:
            st.error(f"Failed to fetch live data: {e}")
            fixtures = []

    if not fixtures:
        st.info("No live matches right now. Check back during match times, or browse by date below.")
    else:
        st.success(f"{len(fixtures)} live match(es) found")
        for fix in fixtures:
            league = fix["league"]
            teams = fix["teams"]
            goals = fix["goals"]
            elapsed = fix["fixture"]["status"]["elapsed"]

            home = teams["home"]["name"]
            away = teams["away"]["name"]
            home_goals = goals["home"] if goals["home"] is not None else 0
            away_goals = goals["away"] if goals["away"] is not None else 0
            minute = f"{elapsed}'" if elapsed else "—"

            with st.container():
                col1, col2, col3 = st.columns([3, 1, 3])
                with col1:
                    logo_url = teams["home"].get("logo", "")
                    if logo_url:
                        st.image(logo_url, width=32)
                    st.markdown(f"**{home}**")
                with col2:
                    st.markdown(
                        f"<div style='text-align:center; font-size:1.4rem; font-weight:bold;'>"
                        f"{home_goals} - {away_goals}</div>"
                        f"<div style='text-align:center; color:red; font-size:0.85rem;'>🔴 {minute}</div>",
                        unsafe_allow_html=True,
                    )
                with col3:
                    logo_url = teams["away"].get("logo", "")
                    if logo_url:
                        st.image(logo_url, width=32)
                    st.markdown(f"**{away}**")

                st.caption(f"🏆 {league['name']} — {league['country']}")
                st.divider()

with tab2:
    st.subheader("Fixtures by Date")
    selected_date = st.date_input("Select date", value=date.today())

    if st.button("📥 Load Fixtures", key="load_date"):
        with st.spinner(f"Fetching fixtures for {selected_date}..."):
            try:
                fixtures = get_fixtures_by_date(str(selected_date))
            except Exception as e:
                st.error(f"Error: {e}")
                fixtures = []

        if not fixtures:
            st.info("No fixtures found for this date.")
        else:
            rows = []
            for fix in fixtures:
                teams = fix["teams"]
                goals = fix["goals"]
                league = fix["league"]
                status = fix["fixture"]["status"]["short"]
                elapsed = fix["fixture"]["status"]["elapsed"]
                kick_off = fix["fixture"]["date"][11:16] if fix["fixture"].get("date") else "—"

                home_goals = goals["home"] if goals["home"] is not None else "—"
                away_goals = goals["away"] if goals["away"] is not None else "—"

                rows.append({
                    "League": league["name"],
                    "Country": league["country"],
                    "Home": teams["home"]["name"],
                    "Score": f"{home_goals} - {away_goals}",
                    "Away": teams["away"]["name"],
                    "Status": status,
                    "Kick-off (UTC)": kick_off,
                })

            df = pd.DataFrame(rows)
            st.dataframe(df, use_container_width=True, hide_index=True)
            st.caption(f"Total: {len(fixtures)} fixture(s)")
