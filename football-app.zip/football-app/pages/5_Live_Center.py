import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import time
from utils.api import get_live_fixtures, get_fixture_statistics

st.set_page_config(page_title="Live Center", page_icon="🔴", layout="wide")

st.title("🔴 Live Center")
st.caption("Real-time match stats and AI-powered insights")

# ── Auto-refresh controls ─────────────────────────────────────────────────────
col_r1, col_r2, col_r3 = st.columns([2, 2, 4])
with col_r1:
    auto_refresh = st.toggle("Auto-refresh", value=False)
with col_r2:
    refresh_interval = st.selectbox("Interval", [30, 60, 120], index=1, format_func=lambda x: f"{x}s")
with col_r3:
    if st.button("🔄 Refresh Now"):
        st.rerun()

st.divider()

# ── Fetch live fixtures ───────────────────────────────────────────────────────
with st.spinner("Fetching live matches..."):
    try:
        fixtures = get_live_fixtures()
    except Exception as e:
        st.error(f"Could not fetch live matches: {e}")
        fixtures = []

if not fixtures:
    st.info("⏳ No matches are live right now. Come back during match hours (typically 12:00–23:00 UTC).")
    if auto_refresh:
        time.sleep(refresh_interval)
        st.rerun()
    st.stop()

st.success(f"**{len(fixtures)} match(es) live** — fetching detailed stats…")

# ── Process each live match ───────────────────────────────────────────────────
def parse_stat(stats_list: list, team_idx: int, stat_name: str):
    try:
        for s in stats_list[team_idx]["statistics"]:
            if s["type"] == stat_name:
                val = s["value"]
                if val is None:
                    return 0
                if isinstance(val, str) and "%" in val:
                    return int(val.replace("%", ""))
                return int(val)
    except (IndexError, KeyError, TypeError, ValueError):
        pass
    return 0

def ai_analyze(home: str, away: str, home_goals: int, away_goals: int,
               home_poss: int, away_poss: int,
               home_shots: int, away_shots: int,
               home_sot: int, away_sot: int,
               home_corners: int, away_corners: int,
               elapsed: int) -> list[dict]:
    alerts = []

    def add(icon, text, level="info"):
        alerts.append({"icon": icon, "text": text, "level": level})

    # Dominant possession but barren
    if home_poss >= 65 and home_sot < 3 and elapsed > 30:
        add("⚠️", f"**{home}** is controlling possession ({home_poss}%) but struggling to test the keeper.", "warning")
    if away_poss >= 65 and away_sot < 3 and elapsed > 30:
        add("⚠️", f"**{away}** is controlling possession ({away_poss}%) but struggling to test the keeper.", "warning")

    # High pressure, no reward
    if home_sot >= 5 and home_goals == 0:
        add("🔥", f"**{home}** has fired {home_sot} shots on target — a goal feels inevitable!", "warning")
    if away_sot >= 5 and away_goals == 0:
        add("🔥", f"**{away}** has fired {away_sot} shots on target — a goal feels inevitable!", "warning")

    # Counter-attack threat: more shots but less possession
    if away_poss < home_poss and away_shots > home_shots and elapsed > 20:
        add("⚡", f"**{away}** is dangerous on the counter — more shots despite less possession!", "error")
    if home_poss < away_poss and home_shots > away_shots and elapsed > 20:
        add("⚡", f"**{home}** is dangerous on the counter — more shots despite less possession!", "error")

    # Comeback scenario
    if home_goals < away_goals and home_poss > 55 and elapsed > 60:
        add("📈", f"**{home}** is chasing the game with {home_poss}% possession in the final stretch.", "info")
    if away_goals < home_goals and away_poss > 55 and elapsed > 60:
        add("📈", f"**{away}** is chasing the game with {away_poss}% possession in the final stretch.", "info")

    # Set piece dominance
    if home_corners >= 7:
        add("🚩", f"**{home}** is winning the set-piece battle with {home_corners} corners — danger in the box!", "info")
    if away_corners >= 7:
        add("🚩", f"**{away}** is winning the set-piece battle with {away_corners} corners — danger in the box!", "info")

    # Tight, low-event match
    if (home_shots + away_shots) < 6 and elapsed > 50:
        add("🔒", "Very tight match with few chances — a single moment could decide everything.", "info")

    # Dominant & clinical
    if home_sot > away_sot + 4 and home_goals > away_goals:
        add("💪", f"**{home}** is completely dominating — both in chances and on the scoreboard.", "info")
    if away_sot > home_sot + 4 and away_goals > home_goals:
        add("💪", f"**{away}** is completely dominating — both in chances and on the scoreboard.", "info")

    if not alerts:
        add("🟡", "Match is evenly contested — no clear statistical dominance yet.", "info")

    return alerts

for fix in fixtures:
    fid      = fix["fixture"]["id"]
    elapsed  = fix["fixture"]["status"]["elapsed"] or 0
    league   = fix["league"]
    teams    = fix["teams"]
    goals    = fix["goals"]
    home     = teams["home"]["name"]
    away     = teams["away"]["name"]
    hg       = goals["home"] if goals["home"] is not None else 0
    ag       = goals["away"] if goals["away"] is not None else 0

    with st.container():
        # Match header
        h1, h2, h3 = st.columns([3, 2, 3])
        with h1:
            if teams["home"].get("logo"):
                st.image(teams["home"]["logo"], width=40)
            st.markdown(f"### {home}")
        with h2:
            st.markdown(
                f"<div style='text-align:center;font-size:2rem;font-weight:900'>{hg} – {ag}</div>"
                f"<div style='text-align:center;color:#e74c3c;font-weight:600'>🔴 {elapsed}'</div>"
                f"<div style='text-align:center;font-size:0.75rem;color:gray'>{league['name']}</div>",
                unsafe_allow_html=True,
            )
        with h3:
            if teams["away"].get("logo"):
                st.image(teams["away"]["logo"], width=40)
            st.markdown(f"### {away}")

        # Fetch stats
        try:
            stats = get_fixture_statistics(fid)
        except Exception:
            stats = []

        if stats and len(stats) >= 2:
            hp  = parse_stat(stats, 0, "Ball Possession")
            ap  = parse_stat(stats, 1, "Ball Possession")
            hs  = parse_stat(stats, 0, "Total Shots")
            as_ = parse_stat(stats, 1, "Total Shots")
            hsot = parse_stat(stats, 0, "Shots on Goal")
            asot = parse_stat(stats, 1, "Shots on Goal")
            hc  = parse_stat(stats, 0, "Corner Kicks")
            ac  = parse_stat(stats, 1, "Corner Kicks")
            hf  = parse_stat(stats, 0, "Fouls")
            af  = parse_stat(stats, 1, "Fouls")
            hyk = parse_stat(stats, 0, "Yellow Cards")
            ayk = parse_stat(stats, 1, "Yellow Cards")

            # ── Stats comparison bars ─────────────────────────────────────────
            st.markdown("#### 📊 Match Stats")
            stat_labels = ["Possession %", "Total Shots", "Shots on Target", "Corners", "Fouls"]
            home_vals   = [hp,  hs,  hsot, hc, hf]
            away_vals   = [ap,  as_, asot, ac, af]

            fig = go.Figure()
            fig.add_trace(go.Bar(
                name=home, y=stat_labels, x=home_vals,
                orientation="h", marker_color="#3498db",
                text=[str(v) for v in home_vals], textposition="inside",
            ))
            fig.add_trace(go.Bar(
                name=away, y=stat_labels, x=[-v for v in away_vals],
                orientation="h", marker_color="#e74c3c",
                text=[str(v) for v in away_vals], textposition="inside",
            ))
            fig.update_layout(
                barmode="overlay",
                xaxis=dict(showticklabels=False, zeroline=True, zerolinecolor="white"),
                height=260,
                margin=dict(l=10, r=10, t=10, b=10),
                plot_bgcolor="rgba(0,0,0,0)",
                paper_bgcolor="rgba(0,0,0,0)",
                legend=dict(orientation="h", y=1.15, x=0.5, xanchor="center"),
                bargap=0.15,
            )
            st.plotly_chart(fig, use_container_width=True)

            # Quick stat pills
            pc1, pc2, pc3, pc4 = st.columns(4)
            pc1.metric("🟡 Yellow Cards", f"{hyk} – {ayk}")
            pc2.metric("⚽ Shots on Target", f"{hsot} – {asot}")
            pc3.metric("🚩 Corners", f"{hc} – {ac}")
            pc4.metric("🤛 Fouls", f"{hf} – {af}")

            # ── AI Smart Alerts ───────────────────────────────────────────────
            st.markdown("#### 🤖 AI Smart Alerts")
            alerts = ai_analyze(home, away, hg, ag, hp, ap, hs, as_, hsot, asot, hc, ac, elapsed)
            for alert in alerts:
                if alert["level"] == "warning":
                    st.warning(f"{alert['icon']} {alert['text']}")
                elif alert["level"] == "error":
                    st.error(f"{alert['icon']} {alert['text']}")
                else:
                    st.info(f"{alert['icon']} {alert['text']}")
        else:
            st.info("Stats not yet available for this match.")

        st.divider()

# ── Auto-refresh loop ─────────────────────────────────────────────────────────
if auto_refresh:
    time.sleep(refresh_interval)
    st.rerun()
