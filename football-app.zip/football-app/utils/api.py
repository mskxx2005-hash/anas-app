import os
import requests

BASE_URL = "https://v3.football.api-sports.io"

def get_headers():
    api_key = os.environ.get("API_FOOTBALL_KEY", "")
    return {
        "x-rapidapi-host": "v3.football.api-sports.io",
        "x-rapidapi-key": api_key,
    }

def get_live_fixtures():
    url = f"{BASE_URL}/fixtures"
    params = {"live": "all"}
    resp = requests.get(url, headers=get_headers(), params=params, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    return data.get("response", [])

def get_fixtures_by_date(date: str):
    url = f"{BASE_URL}/fixtures"
    params = {"date": date}
    resp = requests.get(url, headers=get_headers(), params=params, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    return data.get("response", [])

def get_standings(league_id: int, season: int):
    url = f"{BASE_URL}/standings"
    params = {"league": league_id, "season": season}
    resp = requests.get(url, headers=get_headers(), params=params, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    try:
        return data["response"][0]["league"]["standings"][0]
    except (IndexError, KeyError):
        return []

def get_top_scorers(league_id: int, season: int):
    url = f"{BASE_URL}/players/topscorers"
    params = {"league": league_id, "season": season}
    resp = requests.get(url, headers=get_headers(), params=params, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    return data.get("response", [])

def get_leagues():
    url = f"{BASE_URL}/leagues"
    params = {"current": "true", "type": "League"}
    resp = requests.get(url, headers=get_headers(), params=params, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    return data.get("response", [])

def get_fixture_statistics(fixture_id: int):
    url = f"{BASE_URL}/fixtures/statistics"
    params = {"fixture": fixture_id}
    resp = requests.get(url, headers=get_headers(), params=params, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    return data.get("response", [])

def get_head_to_head(team1_id: int, team2_id: int, last: int = 10):
    url = f"{BASE_URL}/fixtures/headtohead"
    params = {"h2h": f"{team1_id}-{team2_id}", "last": last}
    resp = requests.get(url, headers=get_headers(), params=params, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    return data.get("response", [])
